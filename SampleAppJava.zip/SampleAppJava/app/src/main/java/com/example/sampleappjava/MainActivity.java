package com.example.sampleappjava;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView Inputvalues,Result;
    MaterialButton buttonBracketOpen,buttonBracketClose,button7,button8,button9,
            button4,button5,button6,button1,button2,button3,
            button0,buttondDot;
    MaterialButton buttonDivide,buttonMultiply,buttonSubtract,buttonAdd,buttonEquals;
    MaterialButton buttonAC,buttonC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Inputvalues = findViewById(R.id.inputvalues);
        Result = findViewById(R.id.Result);

        assignID(buttonC, R.id.Button_C);
        assignID(buttonBracketOpen, R.id.Button_openBracket);
        assignID(buttonBracketClose, R.id.Button_closeBracket);
        assignID(button7, R.id.Button_7);
        assignID(button8, R.id.Button_8);
        assignID(button9, R.id.Button_9);
        assignID(button6, R.id.Button_6);
        assignID(button5, R.id.Button_5);
        assignID(button4, R.id.Button_4);
        assignID(button3, R.id.Button_3);
        assignID(button2, R.id.Button_2);
        assignID(button1, R.id.Button_1);
        assignID(button0, R.id.Button_0);
        assignID(buttondDot, R.id.Button_dot);
        assignID(buttonDivide, R.id.Button_divide);
        assignID(buttonMultiply, R.id.Button_multply);
        assignID(buttonSubtract, R.id.Button_subtraction);
        assignID(buttonAdd, R.id.Button_add);
        assignID(buttonEquals, R.id.Button_equals);
        assignID(buttonAC, R.id.Button_AC);

    }
    //Create a meth od to assign all other button id
    void assignID(MaterialButton btn, int id){
        btn = findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        MaterialButton button = (MaterialButton) v;
        String buttontext = button.getText().toString();

        String Inputsolution = Inputvalues.getText().toString();

        if(buttontext.equals("AC")){
            Inputvalues.setText("");
            Result.setText("0");
            return;
        }
        if(buttontext.equals("=")){
            Inputvalues.setText(Result.getText());
            return;
        }
        if(buttontext.equals("C")){
          Inputsolution = Inputsolution.substring(0,Inputsolution.length() - 1);
        }
        else{
            Inputsolution =Inputsolution + buttontext;
        }

        Inputvalues.setText(Inputsolution);
        String FinalResult = getResult(Inputsolution);

        if(!FinalResult.equals("Error")){
            Result.setText(FinalResult);
        }else {
            Result.setText("Error");
        }
    }
    String getResult(String data){

        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObject();
           String FinalResult = context.evaluateString(scriptable,data, "Javascript", 1, null).toString();
           if(FinalResult.endsWith(".0")){
               FinalResult = FinalResult.replace(".0", "");
           }
           return FinalResult;
        }catch (Exception e){
            return "Error";
        }

    }
}