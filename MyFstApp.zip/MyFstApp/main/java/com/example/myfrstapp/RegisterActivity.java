package com.example.myfrstapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {

    TextView logintext;
    Button registerbutton;
    EditText edEmail,edPassword,edConfirmPassword,edUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        logintext = findViewById(R.id.Logintext);
        registerbutton = findViewById(R.id.Registerbtn);
        edEmail = findViewById(R.id.email);
        edPassword = findViewById(R.id.password);
        edUsername = findViewById(R.id.username);
        edConfirmPassword = findViewById(R.id.confirmpassword);

        logintext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });
        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String  Username = edUsername.getText().toString();
                String Password = edPassword.getText().toString();
                String Confirmpassword = edConfirmPassword.getText().toString();
                String Email= edEmail.getText().toString();

                Database dbs = new Database(getApplicationContext(),"registeruser123",null,1);

                if(Username.length() == 0 || Password.length() == 0 || Email.length() == 0 || Confirmpassword.length() == 0){
                    Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_SHORT).show();
                }
                else {
                     if(Password.compareTo(Confirmpassword) == 0){

                         if(validpassword(Password)){
                           dbs.register(Username,Email,Password);
                             Toast.makeText(getApplicationContext(),"Registration successful",Toast.LENGTH_SHORT).show();
                             startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                         }else{
                             Toast.makeText(getApplicationContext(),"Password should contain atleast 8 character and '1..9',A-Z,'symbols(@,#,!,_...)",Toast.LENGTH_SHORT).show();
                         }

                     }
                     else{
                         Toast.makeText(getApplicationContext(),"Password Don't Match",Toast.LENGTH_SHORT).show();
                     }

                }
            }
        });

    }
    //Method to check if password contain all the require fomat that is number,char and symbols
    public static boolean validpassword(String passwordEntered){
        int f1=0, f2=0, f3=0;
        if (passwordEntered.length() < 8) {
            return false;
        }else{
            for (int p = 0; p < passwordEntered.length(); p++){
                if(Character.isLetter(passwordEntered.charAt(p))){
                    f1 =1;
                }
            }
            for (int r = 0; r < passwordEntered.length(); r++){
                if(Character.isDigit(passwordEntered.charAt(r))){
                    f2 =1;
                }
            }
            for (int s = 0; s < passwordEntered.length(); s++){
                char c = passwordEntered.charAt(s);
                if(c >= 33 && c <= 46 || c == 64){
                    f3 =1;
                }
            }
            if (f1 == 1 && f2 == 1 && f3 == 1)
                return true;
            return false;

        }
    }
}